In this project I will try to duplicate the Google home page.
It's a way to test my new competencies in HTML/CSS.


This is from The Odin Project's [curriculum]
(http://www.theodinproject.com/courses/web-development-101/lessons/html-css)